/**
 * Spring Security configuration.
 */
package com.parking.security;
