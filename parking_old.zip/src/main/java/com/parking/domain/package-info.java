/**
 * JPA domain objects.
 */
package com.parking.domain;
