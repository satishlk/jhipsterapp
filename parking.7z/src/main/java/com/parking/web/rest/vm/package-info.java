/**
 * View Models used by Spring MVC REST controllers.
 */
package com.parking.web.rest.vm;
