/**
 * Service layer beans.
 */
package com.parking.service;
