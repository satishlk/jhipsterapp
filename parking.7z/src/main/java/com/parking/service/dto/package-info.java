/**
 * Data Transfer Objects.
 */
package com.parking.service.dto;
