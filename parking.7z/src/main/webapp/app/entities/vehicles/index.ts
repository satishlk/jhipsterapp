export * from './vehicles.model';
export * from './vehicles-popup.service';
export * from './vehicles.service';
export * from './vehicles-dialog.component';
export * from './vehicles-delete-dialog.component';
export * from './vehicles-detail.component';
export * from './vehicles.component';
export * from './vehicles.route';
